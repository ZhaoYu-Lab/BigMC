</div>
	
<div id="left">
	<div class="box">
			<h2>GitHub:</h2>	
			<a href="https://github.com/bigmc/bigmc">BigMC Git Repository</a>
	</div>
	<div class="box">
<p>This work funded in part by the Danish Research Agency (grant no.:  2106-080046)
       and the <a href="http://itu.dk">IT University of Copenhagen</a> (the <a href="http://www.itu.dk/en/Forskning/Forskningsprojekter/Jingling-Genies">Jingling Genies project</a>)</p>
		
		<center>&copy; Copyright 2011 <a href="http://itu.dk/~gdpe/">Gian Perrone</a></center>
	</div>
</div>
</div>
</body>
</html>


